from datetime import datetime
import pandas as pd

def audit_matrix_check(df, risk_df, nc_df):
    today = datetime.today().date()
    results = []
    for _, row in df.iterrows():
        alerts = []
        if row["Self-Assessment"] == "Yes" and not row["Evidence Doc ID"]:
            alerts.append("🚫 Thiếu bằng chứng")
        if row["Due Date"]:
            try:
                due_date = pd.to_datetime(row["Due Date"], errors='coerce').date()
                if due_date and due_date < today:
                    alerts.append("⏰ Quá hạn")
            except:
                alerts.append("📅 Lỗi định dạng ngày")
        standards = ["GDPR Article", "ISO 27701 Clause", "US AI BoR Principle", "NIST SP800-53 Control"]
        for std in standards:
            if not row[std]:
                alerts.append(f"🔍 Thiếu Mapping {std}")
        high_risks = risk_df[risk_df["Risk Score"] > 10]["Risk ID"].tolist()
        if row["Evidence Doc ID"] in risk_df["Mitigation / Control"].values:
            for risk_id in high_risks:
                if risk_id in risk_df[risk_df["Mitigation / Control"].str.contains(row["Evidence Doc ID"])]["Risk ID"].values:
                    alerts.append(f"🔥 Rủi ro cao: {risk_id}")
        if row["Evidence Doc ID"] in nc_df["Corrective Action"].values:
            nc_status = nc_df[nc_df["Corrective Action"].str.contains(row["Evidence Doc ID"])]["Verified (Y/N)"].values
            if "N" in nc_status:
                alerts.append("⚠️ Chưa khắc phục phi chuẩn")
        results.append(", ".join(alerts) if alerts else "✅ OK")
    return results
